const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');

const token = '7206231695:AAG_0iUhIYr39CN9QxRt44ashEkKaIyl7Ng';
const bot = new TelegramBot(token, { polling: true });

console.log('Бот запущен...');

function loadPodkats() {
    try {
        const data = fs.readFileSync('podkats.json', 'utf8');
        const parsedData = JSON.parse(data);
        if (!Array.isArray(parsedData.podkats)) {
            throw new Error('Неверный формат данных в podkats.json');
        }
        return parsedData.podkats;
    } catch (error) {
        console.error('Ошибка при загрузке подкатов:', error.message);
        process.exit(1);
    }
}

const podkats = loadPodkats();
let userNames = {};

// Команда /start
bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, 'Привет! Напиши свое имя, и я скажу тебе подкат!');
});

// Команда /help
bot.onText(/\/help/, (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, 'Доступные команды:\n/start - Начать общение\n/reset - Сбросить имя\n/help - Получить помощь');
});

// Команда /reset
bot.onText(/\/reset/, (msg) => {
    const chatId = msg.chat.id;
    delete userNames[chatId];
    bot.sendMessage(chatId, 'Имя сброшено. Жду новое имя!');
});

// Обработка текстовых сообщений
bot.on('message', (msg) => {
    const chatId = msg.chat.id;

    if (msg.text && !msg.text.startsWith('/')) {
        const userName = msg.text.trim();
        
        // Проверка имени с помощью регулярного выражения
        // Разрешаем: буквы (русские и английские), цифры, некоторые символы
        // Но запрещаем строки, состоящие только из цифр или символов
        const nameRegex = /^(?=.*[a-zA-Zа-яА-Я])[\w\dа-яА-Я\s\-_!?@#$%^&*()+=.,;:'"]+$/i;
        
        if (!nameRegex.test(userName)) {
            bot.sendMessage(chatId, 'Имя должно содержать хотя бы одну букву (русскую или английскую). Цифры и символы разрешены только вместе с буквами.');
            return;
        }
        
        // Если имя прошло проверку
        userNames[chatId] = userName;
        sendPodkat(chatId, userName);
    }
});

// Обработка callback-запросов
bot.on('callback_query', (callbackQuery) => {
    const chatId = callbackQuery.message.chat.id;

    if (callbackQuery.data === 'new_podkat') {
        const userName = userNames[chatId];

        if (!userName) {
            bot.sendMessage(chatId, 'Имя не найдено. Пожалуйста, отправьте новое имя.');
            return;
        }

        sendPodkat(chatId, userName);
    }
});

function sendPodkat(chatId, userName) {
    const randomPodkat = podkats[Math.floor(Math.random() * podkats.length)];
    const personalizedPodkat = randomPodkat.replace(/Имя/g, userName);

    bot.sendMessage(chatId, personalizedPodkat, {
        reply_markup: {
            inline_keyboard: [
                [
                    {
                        text: 'Ещё подкат!',
                        callback_data: 'new_podkat'
                    }
                ]
            ]
        }
    });
}